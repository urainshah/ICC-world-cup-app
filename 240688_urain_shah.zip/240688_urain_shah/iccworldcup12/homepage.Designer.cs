﻿
namespace iccworldcup12
{
    partial class homepage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.CountryDetails = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.datagrid = new System.Windows.Forms.DataGridView();
            this.bnupdate = new System.Windows.Forms.Button();
            this.bndelete = new System.Windows.Forms.Button();
            this.bnadd = new System.Windows.Forms.Button();
            this.txtcaptain = new System.Windows.Forms.TextBox();
            this.txtranking = new System.Windows.Forms.TextBox();
            this.txtname = new System.Windows.Forms.TextBox();
            this.txtid = new System.Windows.Forms.TextBox();
            this.lbranking = new System.Windows.Forms.Label();
            this.lbcaptain = new System.Windows.Forms.Label();
            this.lbname = new System.Windows.Forms.Label();
            this.lbid = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.datagrid1 = new System.Windows.Forms.DataGridView();
            this.bnupdate1 = new System.Windows.Forms.Button();
            this.bndelete1 = new System.Windows.Forms.Button();
            this.bnadd1 = new System.Windows.Forms.Button();
            this.txtmatch = new System.Windows.Forms.TextBox();
            this.txtplayer = new System.Windows.Forms.TextBox();
            this.txtplayername = new System.Windows.Forms.TextBox();
            this.txtrole = new System.Windows.Forms.TextBox();
            this.txticcrank = new System.Windows.Forms.TextBox();
            this.txtcountryid = new System.Windows.Forms.TextBox();
            this.lbmatch = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.lbiccrank = new System.Windows.Forms.Label();
            this.lbrole = new System.Windows.Forms.Label();
            this.lbcountryid = new System.Windows.Forms.Label();
            this.lbplayername = new System.Windows.Forms.Label();
            this.lbplayerid = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.datagrid3 = new System.Windows.Forms.DataGridView();
            this.btupdate3 = new System.Windows.Forms.Button();
            this.btdelete3 = new System.Windows.Forms.Button();
            this.btadd3 = new System.Windows.Forms.Button();
            this.txtresult = new System.Windows.Forms.TextBox();
            this.txtvenue = new System.Windows.Forms.TextBox();
            this.txtmatchdate = new System.Windows.Forms.TextBox();
            this.txtcountry2 = new System.Windows.Forms.TextBox();
            this.txtcountry1 = new System.Windows.Forms.TextBox();
            this.txtmatchno = new System.Windows.Forms.TextBox();
            this.lbresult = new System.Windows.Forms.Label();
            this.lbvenue = new System.Windows.Forms.Label();
            this.lbmatchdate = new System.Windows.Forms.Label();
            this.lbcountry_id2 = new System.Windows.Forms.Label();
            this.lbcountry_id1 = new System.Windows.Forms.Label();
            this.lbmatchno = new System.Windows.Forms.Label();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.datagrid4 = new System.Windows.Forms.DataGridView();
            this.btupdate = new System.Windows.Forms.Button();
            this.btdelete = new System.Windows.Forms.Button();
            this.btadd = new System.Windows.Forms.Button();
            this.txtresultt = new System.Windows.Forms.TextBox();
            this.txtvenuee = new System.Windows.Forms.TextBox();
            this.txtmatch_date = new System.Windows.Forms.TextBox();
            this.txtcountryno2 = new System.Windows.Forms.TextBox();
            this.txtcountryno1 = new System.Windows.Forms.TextBox();
            this.txtmatch_no = new System.Windows.Forms.TextBox();
            this.lbresultt = new System.Windows.Forms.Label();
            this.lbvenuee = new System.Windows.Forms.Label();
            this.lbmatch_date = new System.Windows.Forms.Label();
            this.lbcountryno2 = new System.Windows.Forms.Label();
            this.lbcountryno1 = new System.Windows.Forms.Label();
            this.lbmatch_no = new System.Windows.Forms.Label();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.lbmatch_noo = new System.Windows.Forms.Label();
            this.lbcountryno11 = new System.Windows.Forms.Label();
            this.lbcountryno22 = new System.Windows.Forms.Label();
            this.lbmatch_datee = new System.Windows.Forms.Label();
            this.lbvenuee1 = new System.Windows.Forms.Label();
            this.lbresultt1 = new System.Windows.Forms.Label();
            this.txtmatch_noo = new System.Windows.Forms.TextBox();
            this.txtcountryno11 = new System.Windows.Forms.TextBox();
            this.txtcountryno22 = new System.Windows.Forms.TextBox();
            this.txtvenuee1 = new System.Windows.Forms.TextBox();
            this.txtmatch_datee = new System.Windows.Forms.TextBox();
            this.txtresultt1 = new System.Windows.Forms.TextBox();
            this.bttdelete = new System.Windows.Forms.Button();
            this.bttupdate = new System.Windows.Forms.Button();
            this.bttadd = new System.Windows.Forms.Button();
            this.datagrid5 = new System.Windows.Forms.DataGridView();
            this.CountryDetails.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.datagrid)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.datagrid1)).BeginInit();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.datagrid3)).BeginInit();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.datagrid4)).BeginInit();
            this.tabPage5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.datagrid5)).BeginInit();
            this.SuspendLayout();
            // 
            // CountryDetails
            // 
            this.CountryDetails.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.CountryDetails.Controls.Add(this.tabPage1);
            this.CountryDetails.Controls.Add(this.tabPage2);
            this.CountryDetails.Controls.Add(this.tabPage3);
            this.CountryDetails.Controls.Add(this.tabPage4);
            this.CountryDetails.Controls.Add(this.tabPage5);
            this.CountryDetails.Location = new System.Drawing.Point(87, 51);
            this.CountryDetails.Name = "CountryDetails";
            this.CountryDetails.SelectedIndex = 0;
            this.CountryDetails.Size = new System.Drawing.Size(706, 542);
            this.CountryDetails.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.datagrid);
            this.tabPage1.Controls.Add(this.bnupdate);
            this.tabPage1.Controls.Add(this.bndelete);
            this.tabPage1.Controls.Add(this.bnadd);
            this.tabPage1.Controls.Add(this.txtcaptain);
            this.tabPage1.Controls.Add(this.txtranking);
            this.tabPage1.Controls.Add(this.txtname);
            this.tabPage1.Controls.Add(this.txtid);
            this.tabPage1.Controls.Add(this.lbranking);
            this.tabPage1.Controls.Add(this.lbcaptain);
            this.tabPage1.Controls.Add(this.lbname);
            this.tabPage1.Controls.Add(this.lbid);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(698, 513);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "tabPage1";
            this.tabPage1.UseVisualStyleBackColor = true;
            this.tabPage1.Click += new System.EventHandler(this.tabPage1_Click);
            // 
            // datagrid
            // 
            this.datagrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.datagrid.Location = new System.Drawing.Point(134, 249);
            this.datagrid.Name = "datagrid";
            this.datagrid.RowHeadersWidth = 51;
            this.datagrid.RowTemplate.Height = 24;
            this.datagrid.Size = new System.Drawing.Size(545, 232);
            this.datagrid.TabIndex = 11;
            this.datagrid.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.datagrid_CellContentClick);
            // 
            // bnupdate
            // 
            this.bnupdate.Location = new System.Drawing.Point(509, 205);
            this.bnupdate.Name = "bnupdate";
            this.bnupdate.Size = new System.Drawing.Size(103, 38);
            this.bnupdate.TabIndex = 10;
            this.bnupdate.Text = "UPDATE";
            this.bnupdate.UseVisualStyleBackColor = true;
            this.bnupdate.Click += new System.EventHandler(this.bnupdate_Click);
            // 
            // bndelete
            // 
            this.bndelete.Location = new System.Drawing.Point(356, 205);
            this.bndelete.Name = "bndelete";
            this.bndelete.Size = new System.Drawing.Size(101, 38);
            this.bndelete.TabIndex = 9;
            this.bndelete.Text = "DELETE";
            this.bndelete.UseVisualStyleBackColor = true;
            this.bndelete.Click += new System.EventHandler(this.bndelete_Click);
            // 
            // bnadd
            // 
            this.bnadd.Location = new System.Drawing.Point(189, 205);
            this.bnadd.Name = "bnadd";
            this.bnadd.Size = new System.Drawing.Size(75, 38);
            this.bnadd.TabIndex = 8;
            this.bnadd.Text = "ADD";
            this.bnadd.UseVisualStyleBackColor = true;
            this.bnadd.Click += new System.EventHandler(this.bnadd_Click);
            // 
            // txtcaptain
            // 
            this.txtcaptain.Location = new System.Drawing.Point(245, 85);
            this.txtcaptain.Name = "txtcaptain";
            this.txtcaptain.Size = new System.Drawing.Size(147, 22);
            this.txtcaptain.TabIndex = 7;
            // 
            // txtranking
            // 
            this.txtranking.Location = new System.Drawing.Point(245, 116);
            this.txtranking.Name = "txtranking";
            this.txtranking.Size = new System.Drawing.Size(147, 22);
            this.txtranking.TabIndex = 6;
            // 
            // txtname
            // 
            this.txtname.Location = new System.Drawing.Point(245, 54);
            this.txtname.Name = "txtname";
            this.txtname.Size = new System.Drawing.Size(147, 22);
            this.txtname.TabIndex = 5;
            // 
            // txtid
            // 
            this.txtid.Location = new System.Drawing.Point(245, 21);
            this.txtid.Name = "txtid";
            this.txtid.Size = new System.Drawing.Size(147, 22);
            this.txtid.TabIndex = 4;
            this.txtid.TextChanged += new System.EventHandler(this.txtid_TextChanged);
            // 
            // lbranking
            // 
            this.lbranking.AutoSize = true;
            this.lbranking.Location = new System.Drawing.Point(9, 116);
            this.lbranking.Name = "lbranking";
            this.lbranking.Size = new System.Drawing.Size(55, 17);
            this.lbranking.TabIndex = 3;
            this.lbranking.Text = "ranking";
            // 
            // lbcaptain
            // 
            this.lbcaptain.AutoSize = true;
            this.lbcaptain.Location = new System.Drawing.Point(12, 85);
            this.lbcaptain.Name = "lbcaptain";
            this.lbcaptain.Size = new System.Drawing.Size(54, 17);
            this.lbcaptain.TabIndex = 2;
            this.lbcaptain.Text = "captain";
            // 
            // lbname
            // 
            this.lbname.AutoSize = true;
            this.lbname.Location = new System.Drawing.Point(9, 54);
            this.lbname.Name = "lbname";
            this.lbname.Size = new System.Drawing.Size(43, 17);
            this.lbname.TabIndex = 1;
            this.lbname.Text = "name";
            // 
            // lbid
            // 
            this.lbid.AutoSize = true;
            this.lbid.Location = new System.Drawing.Point(6, 21);
            this.lbid.Name = "lbid";
            this.lbid.Size = new System.Drawing.Size(74, 17);
            this.lbid.TabIndex = 0;
            this.lbid.Text = "country_id";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.datagrid1);
            this.tabPage2.Controls.Add(this.bnupdate1);
            this.tabPage2.Controls.Add(this.bndelete1);
            this.tabPage2.Controls.Add(this.bnadd1);
            this.tabPage2.Controls.Add(this.txtmatch);
            this.tabPage2.Controls.Add(this.txtplayer);
            this.tabPage2.Controls.Add(this.txtplayername);
            this.tabPage2.Controls.Add(this.txtrole);
            this.tabPage2.Controls.Add(this.txticcrank);
            this.tabPage2.Controls.Add(this.txtcountryid);
            this.tabPage2.Controls.Add(this.lbmatch);
            this.tabPage2.Controls.Add(this.label7);
            this.tabPage2.Controls.Add(this.lbiccrank);
            this.tabPage2.Controls.Add(this.lbrole);
            this.tabPage2.Controls.Add(this.lbcountryid);
            this.tabPage2.Controls.Add(this.lbplayername);
            this.tabPage2.Controls.Add(this.lbplayerid);
            this.tabPage2.Controls.Add(this.label1);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(698, 513);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "tabPage2";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // datagrid1
            // 
            this.datagrid1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.datagrid1.Location = new System.Drawing.Point(131, 244);
            this.datagrid1.Name = "datagrid1";
            this.datagrid1.RowHeadersWidth = 51;
            this.datagrid1.RowTemplate.Height = 24;
            this.datagrid1.Size = new System.Drawing.Size(548, 237);
            this.datagrid1.TabIndex = 17;
            this.datagrid1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.datagrid1_CellContentClick);
            // 
            // bnupdate1
            // 
            this.bnupdate1.Location = new System.Drawing.Point(504, 199);
            this.bnupdate1.Name = "bnupdate1";
            this.bnupdate1.Size = new System.Drawing.Size(85, 39);
            this.bnupdate1.TabIndex = 16;
            this.bnupdate1.Text = "update";
            this.bnupdate1.UseVisualStyleBackColor = true;
            this.bnupdate1.Click += new System.EventHandler(this.bnupdate1_Click);
            // 
            // bndelete1
            // 
            this.bndelete1.Location = new System.Drawing.Point(356, 199);
            this.bndelete1.Name = "bndelete1";
            this.bndelete1.Size = new System.Drawing.Size(75, 39);
            this.bndelete1.TabIndex = 15;
            this.bndelete1.Text = "Delete";
            this.bndelete1.UseVisualStyleBackColor = true;
            this.bndelete1.Click += new System.EventHandler(this.bndelete1_Click);
            // 
            // bnadd1
            // 
            this.bnadd1.Location = new System.Drawing.Point(202, 199);
            this.bnadd1.Name = "bnadd1";
            this.bnadd1.Size = new System.Drawing.Size(75, 39);
            this.bnadd1.TabIndex = 14;
            this.bnadd1.Text = "Add";
            this.bnadd1.UseVisualStyleBackColor = true;
            this.bnadd1.Click += new System.EventHandler(this.bnadd1_Click);
            // 
            // txtmatch
            // 
            this.txtmatch.Location = new System.Drawing.Point(274, 160);
            this.txtmatch.Name = "txtmatch";
            this.txtmatch.Size = new System.Drawing.Size(157, 22);
            this.txtmatch.TabIndex = 13;
            // 
            // txtplayer
            // 
            this.txtplayer.Location = new System.Drawing.Point(274, 15);
            this.txtplayer.Name = "txtplayer";
            this.txtplayer.Size = new System.Drawing.Size(157, 22);
            this.txtplayer.TabIndex = 12;
            this.txtplayer.TextChanged += new System.EventHandler(this.txtplayer_TextChanged);
            // 
            // txtplayername
            // 
            this.txtplayername.Location = new System.Drawing.Point(274, 43);
            this.txtplayername.Name = "txtplayername";
            this.txtplayername.Size = new System.Drawing.Size(157, 22);
            this.txtplayername.TabIndex = 11;
            this.txtplayername.TextChanged += new System.EventHandler(this.txtplayername_TextChanged);
            // 
            // txtrole
            // 
            this.txtrole.Location = new System.Drawing.Point(274, 99);
            this.txtrole.Name = "txtrole";
            this.txtrole.Size = new System.Drawing.Size(157, 22);
            this.txtrole.TabIndex = 10;
            // 
            // txticcrank
            // 
            this.txticcrank.Location = new System.Drawing.Point(274, 129);
            this.txticcrank.Name = "txticcrank";
            this.txticcrank.Size = new System.Drawing.Size(157, 22);
            this.txticcrank.TabIndex = 9;
            // 
            // txtcountryid
            // 
            this.txtcountryid.Location = new System.Drawing.Point(274, 71);
            this.txtcountryid.Name = "txtcountryid";
            this.txtcountryid.Size = new System.Drawing.Size(157, 22);
            this.txtcountryid.TabIndex = 8;
            // 
            // lbmatch
            // 
            this.lbmatch.AutoSize = true;
            this.lbmatch.Location = new System.Drawing.Point(29, 163);
            this.lbmatch.Name = "lbmatch";
            this.lbmatch.Size = new System.Drawing.Size(107, 17);
            this.lbmatch.TabIndex = 7;
            this.lbmatch.Text = "matches played";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(29, 60);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(0, 17);
            this.label7.TabIndex = 6;
            // 
            // lbiccrank
            // 
            this.lbiccrank.AutoSize = true;
            this.lbiccrank.Location = new System.Drawing.Point(29, 134);
            this.lbiccrank.Name = "lbiccrank";
            this.lbiccrank.Size = new System.Drawing.Size(76, 17);
            this.lbiccrank.TabIndex = 5;
            this.lbiccrank.Text = "icc ranking";
            // 
            // lbrole
            // 
            this.lbrole.AutoSize = true;
            this.lbrole.Location = new System.Drawing.Point(29, 107);
            this.lbrole.Name = "lbrole";
            this.lbrole.Size = new System.Drawing.Size(32, 17);
            this.lbrole.TabIndex = 4;
            this.lbrole.Text = "role";
            this.lbrole.Click += new System.EventHandler(this.label5_Click);
            // 
            // lbcountryid
            // 
            this.lbcountryid.AutoSize = true;
            this.lbcountryid.Location = new System.Drawing.Point(29, 77);
            this.lbcountryid.Name = "lbcountryid";
            this.lbcountryid.Size = new System.Drawing.Size(70, 17);
            this.lbcountryid.TabIndex = 3;
            this.lbcountryid.Text = "country id";
            // 
            // lbplayername
            // 
            this.lbplayername.AutoSize = true;
            this.lbplayername.Location = new System.Drawing.Point(29, 41);
            this.lbplayername.Name = "lbplayername";
            this.lbplayername.Size = new System.Drawing.Size(86, 17);
            this.lbplayername.TabIndex = 2;
            this.lbplayername.Text = "player name";
            this.lbplayername.Click += new System.EventHandler(this.label3_Click);
            // 
            // lbplayerid
            // 
            this.lbplayerid.AutoSize = true;
            this.lbplayerid.Location = new System.Drawing.Point(29, 15);
            this.lbplayerid.Name = "lbplayerid";
            this.lbplayerid.Size = new System.Drawing.Size(62, 17);
            this.lbplayerid.TabIndex = 1;
            this.lbplayerid.Text = "player id";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(29, 41);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 17);
            this.label1.TabIndex = 0;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.datagrid3);
            this.tabPage3.Controls.Add(this.btupdate3);
            this.tabPage3.Controls.Add(this.btdelete3);
            this.tabPage3.Controls.Add(this.btadd3);
            this.tabPage3.Controls.Add(this.txtresult);
            this.tabPage3.Controls.Add(this.txtvenue);
            this.tabPage3.Controls.Add(this.txtmatchdate);
            this.tabPage3.Controls.Add(this.txtcountry2);
            this.tabPage3.Controls.Add(this.txtcountry1);
            this.tabPage3.Controls.Add(this.txtmatchno);
            this.tabPage3.Controls.Add(this.lbresult);
            this.tabPage3.Controls.Add(this.lbvenue);
            this.tabPage3.Controls.Add(this.lbmatchdate);
            this.tabPage3.Controls.Add(this.lbcountry_id2);
            this.tabPage3.Controls.Add(this.lbcountry_id1);
            this.tabPage3.Controls.Add(this.lbmatchno);
            this.tabPage3.Location = new System.Drawing.Point(4, 25);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(698, 513);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "tabPage3";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // datagrid3
            // 
            this.datagrid3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.datagrid3.Location = new System.Drawing.Point(174, 271);
            this.datagrid3.Name = "datagrid3";
            this.datagrid3.RowHeadersWidth = 51;
            this.datagrid3.RowTemplate.Height = 24;
            this.datagrid3.Size = new System.Drawing.Size(509, 228);
            this.datagrid3.TabIndex = 15;
            // 
            // btupdate3
            // 
            this.btupdate3.Location = new System.Drawing.Point(531, 220);
            this.btupdate3.Name = "btupdate3";
            this.btupdate3.Size = new System.Drawing.Size(86, 29);
            this.btupdate3.TabIndex = 14;
            this.btupdate3.Text = "UPDATE";
            this.btupdate3.UseVisualStyleBackColor = true;
            this.btupdate3.Click += new System.EventHandler(this.btupdate3_Click);
            // 
            // btdelete3
            // 
            this.btdelete3.Location = new System.Drawing.Point(364, 220);
            this.btdelete3.Name = "btdelete3";
            this.btdelete3.Size = new System.Drawing.Size(85, 29);
            this.btdelete3.TabIndex = 13;
            this.btdelete3.Text = "DELETE";
            this.btdelete3.UseVisualStyleBackColor = true;
            this.btdelete3.Click += new System.EventHandler(this.btdelete3_Click);
            // 
            // btadd3
            // 
            this.btadd3.Location = new System.Drawing.Point(202, 221);
            this.btadd3.Name = "btadd3";
            this.btadd3.Size = new System.Drawing.Size(75, 28);
            this.btadd3.TabIndex = 12;
            this.btadd3.Text = "ADD";
            this.btadd3.UseVisualStyleBackColor = true;
            this.btadd3.Click += new System.EventHandler(this.btadd3_Click);
            // 
            // txtresult
            // 
            this.txtresult.Location = new System.Drawing.Point(317, 181);
            this.txtresult.Name = "txtresult";
            this.txtresult.Size = new System.Drawing.Size(186, 22);
            this.txtresult.TabIndex = 11;
            // 
            // txtvenue
            // 
            this.txtvenue.Location = new System.Drawing.Point(317, 152);
            this.txtvenue.Name = "txtvenue";
            this.txtvenue.Size = new System.Drawing.Size(186, 22);
            this.txtvenue.TabIndex = 10;
            // 
            // txtmatchdate
            // 
            this.txtmatchdate.Location = new System.Drawing.Point(317, 123);
            this.txtmatchdate.Name = "txtmatchdate";
            this.txtmatchdate.Size = new System.Drawing.Size(186, 22);
            this.txtmatchdate.TabIndex = 9;
            // 
            // txtcountry2
            // 
            this.txtcountry2.Location = new System.Drawing.Point(317, 94);
            this.txtcountry2.Name = "txtcountry2";
            this.txtcountry2.Size = new System.Drawing.Size(186, 22);
            this.txtcountry2.TabIndex = 8;
            // 
            // txtcountry1
            // 
            this.txtcountry1.Location = new System.Drawing.Point(317, 60);
            this.txtcountry1.Name = "txtcountry1";
            this.txtcountry1.Size = new System.Drawing.Size(186, 22);
            this.txtcountry1.TabIndex = 7;
            // 
            // txtmatchno
            // 
            this.txtmatchno.Location = new System.Drawing.Point(317, 26);
            this.txtmatchno.Name = "txtmatchno";
            this.txtmatchno.Size = new System.Drawing.Size(186, 22);
            this.txtmatchno.TabIndex = 6;
            // 
            // lbresult
            // 
            this.lbresult.AutoSize = true;
            this.lbresult.Location = new System.Drawing.Point(36, 176);
            this.lbresult.Name = "lbresult";
            this.lbresult.Size = new System.Drawing.Size(63, 17);
            this.lbresult.TabIndex = 5;
            this.lbresult.Text = "RESULT";
            // 
            // lbvenue
            // 
            this.lbvenue.AutoSize = true;
            this.lbvenue.Location = new System.Drawing.Point(36, 148);
            this.lbvenue.Name = "lbvenue";
            this.lbvenue.Size = new System.Drawing.Size(55, 17);
            this.lbvenue.TabIndex = 4;
            this.lbvenue.Text = "VENUE";
            // 
            // lbmatchdate
            // 
            this.lbmatchdate.AutoSize = true;
            this.lbmatchdate.Location = new System.Drawing.Point(36, 122);
            this.lbmatchdate.Name = "lbmatchdate";
            this.lbmatchdate.Size = new System.Drawing.Size(101, 17);
            this.lbmatchdate.TabIndex = 3;
            this.lbmatchdate.Text = "MATCH_DATE";
            this.lbmatchdate.Click += new System.EventHandler(this.label5_Click_1);
            // 
            // lbcountry_id2
            // 
            this.lbcountry_id2.AutoSize = true;
            this.lbcountry_id2.Location = new System.Drawing.Point(36, 94);
            this.lbcountry_id2.Name = "lbcountry_id2";
            this.lbcountry_id2.Size = new System.Drawing.Size(84, 17);
            this.lbcountry_id2.TabIndex = 2;
            this.lbcountry_id2.Text = "COUNTRY2";
            // 
            // lbcountry_id1
            // 
            this.lbcountry_id1.AutoSize = true;
            this.lbcountry_id1.Location = new System.Drawing.Point(36, 60);
            this.lbcountry_id1.Name = "lbcountry_id1";
            this.lbcountry_id1.Size = new System.Drawing.Size(84, 17);
            this.lbcountry_id1.TabIndex = 1;
            this.lbcountry_id1.Text = "COUNTRY1";
            // 
            // lbmatchno
            // 
            this.lbmatchno.AutoSize = true;
            this.lbmatchno.Location = new System.Drawing.Point(36, 32);
            this.lbmatchno.Name = "lbmatchno";
            this.lbmatchno.Size = new System.Drawing.Size(85, 17);
            this.lbmatchno.TabIndex = 0;
            this.lbmatchno.Text = "MATCH_NO";
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.datagrid4);
            this.tabPage4.Controls.Add(this.btupdate);
            this.tabPage4.Controls.Add(this.btdelete);
            this.tabPage4.Controls.Add(this.btadd);
            this.tabPage4.Controls.Add(this.txtresultt);
            this.tabPage4.Controls.Add(this.txtvenuee);
            this.tabPage4.Controls.Add(this.txtmatch_date);
            this.tabPage4.Controls.Add(this.txtcountryno2);
            this.tabPage4.Controls.Add(this.txtcountryno1);
            this.tabPage4.Controls.Add(this.txtmatch_no);
            this.tabPage4.Controls.Add(this.lbresultt);
            this.tabPage4.Controls.Add(this.lbvenuee);
            this.tabPage4.Controls.Add(this.lbmatch_date);
            this.tabPage4.Controls.Add(this.lbcountryno2);
            this.tabPage4.Controls.Add(this.lbcountryno1);
            this.tabPage4.Controls.Add(this.lbmatch_no);
            this.tabPage4.Location = new System.Drawing.Point(4, 25);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(698, 513);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "tabPage4";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // datagrid4
            // 
            this.datagrid4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.datagrid4.Location = new System.Drawing.Point(164, 273);
            this.datagrid4.Name = "datagrid4";
            this.datagrid4.RowHeadersWidth = 51;
            this.datagrid4.RowTemplate.Height = 24;
            this.datagrid4.Size = new System.Drawing.Size(531, 237);
            this.datagrid4.TabIndex = 15;
            // 
            // btupdate
            // 
            this.btupdate.Location = new System.Drawing.Point(505, 218);
            this.btupdate.Name = "btupdate";
            this.btupdate.Size = new System.Drawing.Size(75, 32);
            this.btupdate.TabIndex = 14;
            this.btupdate.Text = "UPDATE";
            this.btupdate.UseVisualStyleBackColor = true;
            this.btupdate.Click += new System.EventHandler(this.btupdate_Click);
            // 
            // btdelete
            // 
            this.btdelete.Location = new System.Drawing.Point(334, 218);
            this.btdelete.Name = "btdelete";
            this.btdelete.Size = new System.Drawing.Size(75, 32);
            this.btdelete.TabIndex = 13;
            this.btdelete.Text = "DELETE";
            this.btdelete.UseVisualStyleBackColor = true;
            this.btdelete.Click += new System.EventHandler(this.btdelete_Click);
            // 
            // btadd
            // 
            this.btadd.Location = new System.Drawing.Point(177, 218);
            this.btadd.Name = "btadd";
            this.btadd.Size = new System.Drawing.Size(75, 31);
            this.btadd.TabIndex = 12;
            this.btadd.Text = "ADD";
            this.btadd.UseVisualStyleBackColor = true;
            this.btadd.Click += new System.EventHandler(this.button1_Click);
            // 
            // txtresultt
            // 
            this.txtresultt.Location = new System.Drawing.Point(293, 169);
            this.txtresultt.Name = "txtresultt";
            this.txtresultt.Size = new System.Drawing.Size(144, 22);
            this.txtresultt.TabIndex = 11;
            // 
            // txtvenuee
            // 
            this.txtvenuee.Location = new System.Drawing.Point(293, 136);
            this.txtvenuee.Name = "txtvenuee";
            this.txtvenuee.Size = new System.Drawing.Size(144, 22);
            this.txtvenuee.TabIndex = 10;
            // 
            // txtmatch_date
            // 
            this.txtmatch_date.Location = new System.Drawing.Point(293, 108);
            this.txtmatch_date.Name = "txtmatch_date";
            this.txtmatch_date.Size = new System.Drawing.Size(144, 22);
            this.txtmatch_date.TabIndex = 9;
            // 
            // txtcountryno2
            // 
            this.txtcountryno2.Location = new System.Drawing.Point(293, 77);
            this.txtcountryno2.Name = "txtcountryno2";
            this.txtcountryno2.Size = new System.Drawing.Size(144, 22);
            this.txtcountryno2.TabIndex = 8;
            // 
            // txtcountryno1
            // 
            this.txtcountryno1.Location = new System.Drawing.Point(293, 51);
            this.txtcountryno1.Name = "txtcountryno1";
            this.txtcountryno1.Size = new System.Drawing.Size(144, 22);
            this.txtcountryno1.TabIndex = 7;
            // 
            // txtmatch_no
            // 
            this.txtmatch_no.Location = new System.Drawing.Point(293, 17);
            this.txtmatch_no.Name = "txtmatch_no";
            this.txtmatch_no.Size = new System.Drawing.Size(144, 22);
            this.txtmatch_no.TabIndex = 6;
            this.txtmatch_no.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // lbresultt
            // 
            this.lbresultt.AutoSize = true;
            this.lbresultt.Location = new System.Drawing.Point(20, 169);
            this.lbresultt.Name = "lbresultt";
            this.lbresultt.Size = new System.Drawing.Size(63, 17);
            this.lbresultt.TabIndex = 5;
            this.lbresultt.Text = "RESULT";
            // 
            // lbvenuee
            // 
            this.lbvenuee.AutoSize = true;
            this.lbvenuee.Location = new System.Drawing.Point(20, 143);
            this.lbvenuee.Name = "lbvenuee";
            this.lbvenuee.Size = new System.Drawing.Size(55, 17);
            this.lbvenuee.TabIndex = 4;
            this.lbvenuee.Text = "VENUE";
            // 
            // lbmatch_date
            // 
            this.lbmatch_date.AutoSize = true;
            this.lbmatch_date.Location = new System.Drawing.Point(20, 113);
            this.lbmatch_date.Name = "lbmatch_date";
            this.lbmatch_date.Size = new System.Drawing.Size(101, 17);
            this.lbmatch_date.TabIndex = 3;
            this.lbmatch_date.Text = "MATCH_DATE";
            // 
            // lbcountryno2
            // 
            this.lbcountryno2.AutoSize = true;
            this.lbcountryno2.Location = new System.Drawing.Point(20, 82);
            this.lbcountryno2.Name = "lbcountryno2";
            this.lbcountryno2.Size = new System.Drawing.Size(84, 17);
            this.lbcountryno2.TabIndex = 2;
            this.lbcountryno2.Text = "COUNTRY2";
            // 
            // lbcountryno1
            // 
            this.lbcountryno1.AutoSize = true;
            this.lbcountryno1.Location = new System.Drawing.Point(20, 51);
            this.lbcountryno1.Name = "lbcountryno1";
            this.lbcountryno1.Size = new System.Drawing.Size(84, 17);
            this.lbcountryno1.TabIndex = 1;
            this.lbcountryno1.Text = "COUNTRY1";
            // 
            // lbmatch_no
            // 
            this.lbmatch_no.AutoSize = true;
            this.lbmatch_no.Location = new System.Drawing.Point(20, 22);
            this.lbmatch_no.Name = "lbmatch_no";
            this.lbmatch_no.Size = new System.Drawing.Size(83, 17);
            this.lbmatch_no.TabIndex = 0;
            this.lbmatch_no.Text = "SEMI-FINAL";
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.datagrid5);
            this.tabPage5.Controls.Add(this.bttadd);
            this.tabPage5.Controls.Add(this.bttupdate);
            this.tabPage5.Controls.Add(this.bttdelete);
            this.tabPage5.Controls.Add(this.txtresultt1);
            this.tabPage5.Controls.Add(this.txtmatch_datee);
            this.tabPage5.Controls.Add(this.txtvenuee1);
            this.tabPage5.Controls.Add(this.txtcountryno22);
            this.tabPage5.Controls.Add(this.txtcountryno11);
            this.tabPage5.Controls.Add(this.txtmatch_noo);
            this.tabPage5.Controls.Add(this.lbresultt1);
            this.tabPage5.Controls.Add(this.lbvenuee1);
            this.tabPage5.Controls.Add(this.lbmatch_datee);
            this.tabPage5.Controls.Add(this.lbcountryno22);
            this.tabPage5.Controls.Add(this.lbcountryno11);
            this.tabPage5.Controls.Add(this.lbmatch_noo);
            this.tabPage5.Location = new System.Drawing.Point(4, 25);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Size = new System.Drawing.Size(698, 513);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "tabPage5";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // lbmatch_noo
            // 
            this.lbmatch_noo.AutoSize = true;
            this.lbmatch_noo.Location = new System.Drawing.Point(16, 31);
            this.lbmatch_noo.Name = "lbmatch_noo";
            this.lbmatch_noo.Size = new System.Drawing.Size(46, 17);
            this.lbmatch_noo.TabIndex = 0;
            this.lbmatch_noo.Text = "FINAL";
            // 
            // lbcountryno11
            // 
            this.lbcountryno11.AutoSize = true;
            this.lbcountryno11.Location = new System.Drawing.Point(16, 60);
            this.lbcountryno11.Name = "lbcountryno11";
            this.lbcountryno11.Size = new System.Drawing.Size(84, 17);
            this.lbcountryno11.TabIndex = 1;
            this.lbcountryno11.Text = "COUNTRY1";
            // 
            // lbcountryno22
            // 
            this.lbcountryno22.AutoSize = true;
            this.lbcountryno22.Location = new System.Drawing.Point(16, 95);
            this.lbcountryno22.Name = "lbcountryno22";
            this.lbcountryno22.Size = new System.Drawing.Size(84, 17);
            this.lbcountryno22.TabIndex = 2;
            this.lbcountryno22.Text = "COUNTRY2";
            // 
            // lbmatch_datee
            // 
            this.lbmatch_datee.AutoSize = true;
            this.lbmatch_datee.Location = new System.Drawing.Point(16, 123);
            this.lbmatch_datee.Name = "lbmatch_datee";
            this.lbmatch_datee.Size = new System.Drawing.Size(98, 17);
            this.lbmatch_datee.TabIndex = 3;
            this.lbmatch_datee.Text = "MATCH-DATE";
            // 
            // lbvenuee1
            // 
            this.lbvenuee1.AutoSize = true;
            this.lbvenuee1.Location = new System.Drawing.Point(16, 156);
            this.lbvenuee1.Name = "lbvenuee1";
            this.lbvenuee1.Size = new System.Drawing.Size(55, 17);
            this.lbvenuee1.TabIndex = 4;
            this.lbvenuee1.Text = "VENUE";
            // 
            // lbresultt1
            // 
            this.lbresultt1.AutoSize = true;
            this.lbresultt1.Location = new System.Drawing.Point(16, 185);
            this.lbresultt1.Name = "lbresultt1";
            this.lbresultt1.Size = new System.Drawing.Size(63, 17);
            this.lbresultt1.TabIndex = 5;
            this.lbresultt1.Text = "RESULT";
            // 
            // txtmatch_noo
            // 
            this.txtmatch_noo.Location = new System.Drawing.Point(374, 31);
            this.txtmatch_noo.Name = "txtmatch_noo";
            this.txtmatch_noo.Size = new System.Drawing.Size(127, 22);
            this.txtmatch_noo.TabIndex = 6;
            this.txtmatch_noo.TextChanged += new System.EventHandler(this.txtmatch_noo_TextChanged);
            // 
            // txtcountryno11
            // 
            this.txtcountryno11.Location = new System.Drawing.Point(374, 59);
            this.txtcountryno11.Name = "txtcountryno11";
            this.txtcountryno11.Size = new System.Drawing.Size(127, 22);
            this.txtcountryno11.TabIndex = 7;
            // 
            // txtcountryno22
            // 
            this.txtcountryno22.Location = new System.Drawing.Point(374, 90);
            this.txtcountryno22.Name = "txtcountryno22";
            this.txtcountryno22.Size = new System.Drawing.Size(127, 22);
            this.txtcountryno22.TabIndex = 8;
            // 
            // txtvenuee1
            // 
            this.txtvenuee1.Location = new System.Drawing.Point(374, 148);
            this.txtvenuee1.Name = "txtvenuee1";
            this.txtvenuee1.Size = new System.Drawing.Size(127, 22);
            this.txtvenuee1.TabIndex = 9;
            // 
            // txtmatch_datee
            // 
            this.txtmatch_datee.Location = new System.Drawing.Point(374, 120);
            this.txtmatch_datee.Name = "txtmatch_datee";
            this.txtmatch_datee.Size = new System.Drawing.Size(127, 22);
            this.txtmatch_datee.TabIndex = 10;
            // 
            // txtresultt1
            // 
            this.txtresultt1.Location = new System.Drawing.Point(374, 176);
            this.txtresultt1.Name = "txtresultt1";
            this.txtresultt1.Size = new System.Drawing.Size(127, 22);
            this.txtresultt1.TabIndex = 11;
            // 
            // bttdelete
            // 
            this.bttdelete.Location = new System.Drawing.Point(351, 226);
            this.bttdelete.Name = "bttdelete";
            this.bttdelete.Size = new System.Drawing.Size(75, 23);
            this.bttdelete.TabIndex = 12;
            this.bttdelete.Text = "DELETE";
            this.bttdelete.UseVisualStyleBackColor = true;
            this.bttdelete.Click += new System.EventHandler(this.bttdelete_Click);
            // 
            // bttupdate
            // 
            this.bttupdate.Location = new System.Drawing.Point(504, 226);
            this.bttupdate.Name = "bttupdate";
            this.bttupdate.Size = new System.Drawing.Size(75, 23);
            this.bttupdate.TabIndex = 13;
            this.bttupdate.Text = "UPDATE";
            this.bttupdate.UseVisualStyleBackColor = true;
            this.bttupdate.Click += new System.EventHandler(this.bttupdate_Click);
            // 
            // bttadd
            // 
            this.bttadd.Location = new System.Drawing.Point(213, 226);
            this.bttadd.Name = "bttadd";
            this.bttadd.Size = new System.Drawing.Size(75, 23);
            this.bttadd.TabIndex = 14;
            this.bttadd.Text = "ADD";
            this.bttadd.UseVisualStyleBackColor = true;
            this.bttadd.Click += new System.EventHandler(this.bttadd_Click);
            // 
            // datagrid5
            // 
            this.datagrid5.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.datagrid5.Location = new System.Drawing.Point(186, 270);
            this.datagrid5.Name = "datagrid5";
            this.datagrid5.RowHeadersWidth = 51;
            this.datagrid5.RowTemplate.Height = 24;
            this.datagrid5.Size = new System.Drawing.Size(488, 228);
            this.datagrid5.TabIndex = 15;
            this.datagrid5.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.datagrid5_CellContentClick);
            // 
            // homepage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(901, 622);
            this.Controls.Add(this.CountryDetails);
            this.Name = "homepage";
            this.Text = "homepage";
            this.Load += new System.EventHandler(this.homepage1_Load);
            this.CountryDetails.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.datagrid)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.datagrid1)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.datagrid3)).EndInit();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.datagrid4)).EndInit();
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.datagrid5)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl CountryDetails;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.DataGridView datagrid;
        private System.Windows.Forms.Button bnupdate;
        private System.Windows.Forms.Button bndelete;
        private System.Windows.Forms.Button bnadd;
        private System.Windows.Forms.TextBox txtcaptain;
        private System.Windows.Forms.TextBox txtranking;
        private System.Windows.Forms.TextBox txtname;
        private System.Windows.Forms.TextBox txtid;
        private System.Windows.Forms.Label lbranking;
        private System.Windows.Forms.Label lbcaptain;
        private System.Windows.Forms.Label lbname;
        private System.Windows.Forms.Label lbid;
        private System.Windows.Forms.Label lbplayername;
        private System.Windows.Forms.Label lbplayerid;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbiccrank;
        private System.Windows.Forms.Label lbrole;
        private System.Windows.Forms.Label lbcountryid;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lbmatch;
        private System.Windows.Forms.Button bnupdate1;
        private System.Windows.Forms.Button bndelete1;
        private System.Windows.Forms.Button bnadd1;
        private System.Windows.Forms.TextBox txtmatch;
        private System.Windows.Forms.TextBox txtplayer;
        private System.Windows.Forms.TextBox txtplayername;
        private System.Windows.Forms.TextBox txtrole;
        private System.Windows.Forms.TextBox txticcrank;
        private System.Windows.Forms.TextBox txtcountryid;
        private System.Windows.Forms.DataGridView datagrid1;
        private System.Windows.Forms.Label lbmatchdate;
        private System.Windows.Forms.Label lbcountry_id2;
        private System.Windows.Forms.Label lbcountry_id1;
        private System.Windows.Forms.Label lbmatchno;
        private System.Windows.Forms.DataGridView datagrid3;
        private System.Windows.Forms.Button btupdate3;
        private System.Windows.Forms.Button btdelete3;
        private System.Windows.Forms.Button btadd3;
        private System.Windows.Forms.TextBox txtresult;
        private System.Windows.Forms.TextBox txtvenue;
        private System.Windows.Forms.TextBox txtmatchdate;
        private System.Windows.Forms.TextBox txtcountry2;
        private System.Windows.Forms.TextBox txtcountry1;
        private System.Windows.Forms.TextBox txtmatchno;
        private System.Windows.Forms.Label lbresult;
        private System.Windows.Forms.Label lbvenue;
        private System.Windows.Forms.DataGridView datagrid4;
        private System.Windows.Forms.Button btupdate;
        private System.Windows.Forms.Button btdelete;
        private System.Windows.Forms.Button btadd;
        private System.Windows.Forms.TextBox txtresultt;
        private System.Windows.Forms.TextBox txtvenuee;
        private System.Windows.Forms.TextBox txtmatch_date;
        private System.Windows.Forms.TextBox txtcountryno2;
        private System.Windows.Forms.TextBox txtcountryno1;
        private System.Windows.Forms.TextBox txtmatch_no;
        private System.Windows.Forms.Label lbresultt;
        private System.Windows.Forms.Label lbvenuee;
        private System.Windows.Forms.Label lbmatch_date;
        private System.Windows.Forms.Label lbcountryno2;
        private System.Windows.Forms.Label lbcountryno1;
        private System.Windows.Forms.Label lbmatch_no;
        private System.Windows.Forms.DataGridView datagrid5;
        private System.Windows.Forms.Button bttadd;
        private System.Windows.Forms.Button bttupdate;
        private System.Windows.Forms.Button bttdelete;
        private System.Windows.Forms.TextBox txtresultt1;
        private System.Windows.Forms.TextBox txtmatch_datee;
        private System.Windows.Forms.TextBox txtvenuee1;
        private System.Windows.Forms.TextBox txtcountryno22;
        private System.Windows.Forms.TextBox txtcountryno11;
        private System.Windows.Forms.TextBox txtmatch_noo;
        private System.Windows.Forms.Label lbresultt1;
        private System.Windows.Forms.Label lbvenuee1;
        private System.Windows.Forms.Label lbmatch_datee;
        private System.Windows.Forms.Label lbcountryno22;
        private System.Windows.Forms.Label lbcountryno11;
        private System.Windows.Forms.Label lbmatch_noo;
    }
}