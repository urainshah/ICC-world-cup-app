﻿
namespace iccworldcup12
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblogin = new System.Windows.Forms.Label();
            this.lbpassword = new System.Windows.Forms.Label();
            this.txtlogin = new System.Windows.Forms.TextBox();
            this.txtpassword = new System.Windows.Forms.TextBox();
            this.bnlogin = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblogin
            // 
            this.lblogin.AutoSize = true;
            this.lblogin.Location = new System.Drawing.Point(77, 68);
            this.lblogin.Name = "lblogin";
            this.lblogin.Size = new System.Drawing.Size(38, 17);
            this.lblogin.TabIndex = 0;
            this.lblogin.Text = "login";
            // 
            // lbpassword
            // 
            this.lbpassword.AutoSize = true;
            this.lbpassword.Location = new System.Drawing.Point(77, 123);
            this.lbpassword.Name = "lbpassword";
            this.lbpassword.Size = new System.Drawing.Size(68, 17);
            this.lbpassword.TabIndex = 1;
            this.lbpassword.Text = "password";
            // 
            // txtlogin
            // 
            this.txtlogin.Location = new System.Drawing.Point(331, 68);
            this.txtlogin.Name = "txtlogin";
            this.txtlogin.Size = new System.Drawing.Size(277, 22);
            this.txtlogin.TabIndex = 2;
            // 
            // txtpassword
            // 
            this.txtpassword.Location = new System.Drawing.Point(331, 123);
            this.txtpassword.Name = "txtpassword";
            this.txtpassword.Size = new System.Drawing.Size(277, 22);
            this.txtpassword.TabIndex = 3;
            // 
            // bnlogin
            // 
            this.bnlogin.Location = new System.Drawing.Point(505, 206);
            this.bnlogin.Name = "bnlogin";
            this.bnlogin.Size = new System.Drawing.Size(103, 33);
            this.bnlogin.TabIndex = 4;
            this.bnlogin.Text = "Login";
            this.bnlogin.UseVisualStyleBackColor = true;
            this.bnlogin.Click += new System.EventHandler(this.bnlogin_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.bnlogin);
            this.Controls.Add(this.txtpassword);
            this.Controls.Add(this.txtlogin);
            this.Controls.Add(this.lbpassword);
            this.Controls.Add(this.lblogin);
            this.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblogin;
        private System.Windows.Forms.Label lbpassword;
        private System.Windows.Forms.TextBox txtlogin;
        private System.Windows.Forms.TextBox txtpassword;
        private System.Windows.Forms.Button bnlogin;
    }
}

