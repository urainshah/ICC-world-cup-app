﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace iccworldcup12
{
    public partial class homepage : Form
    {
        dataaccesslayer d = new dataaccesslayer();
        nttdbEntities1 obj = new nttdbEntities1();
        public homepage()
        {
            InitializeComponent();
        }

        private void bnadd_Click(object sender, EventArgs e)
        {
            long c_id = long.Parse(txtid.Text);
            string c_name = txtname.Text;
            string c_captain = txtcaptain.Text;
            long rank = long.Parse(txtranking.Text);
            d.AddCountry(c_id, c_name, c_captain, rank);
            obj.SaveChanges();
            MessageBox.Show("Added successfully");
            loadData();

        }

        void loadData()
        {
            var st = from s in obj.Country_Details select s;
            datagrid.DataSource = st.ToList();
        }
        private void homepage_Load(object sender, EventArgs e)
        {
            loadData();
        }
        private void bndelete_Click(object sender, EventArgs e)
        {

            DialogResult dr = MessageBox.Show("Are you sure to delete data?", "Alert", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            if (dr == DialogResult.Yes)
            {
                long c_id = long.Parse(txtid.Text);
                d.deletecountry(c_id);
                obj.SaveChanges();
                MessageBox.Show("Deleted sucessfully ");
                loadData();
            }
            else
            {
                MessageBox.Show("You have cancelled deletion", "Abort", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

        }

        private void datagrid_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        void loaddata1()
        {
            var st = from s in obj.Player_Details select s;
            datagrid1.DataSource = st.ToList();
        }
        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void bnupdate_Click(object sender, EventArgs e)
        {

            long c_id = long.Parse(txtid.Text);
            long c_id1 = c_id;
            string c_name = txtname.Text;
            string c_captain = txtcaptain.Text;
            long rank = long.Parse(txtranking.Text);
            d.updatecountry(c_id1, c_id, c_name, c_captain, rank);
            obj.SaveChanges();
            MessageBox.Show("Updated sucessfully ");
            loadData();


        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void bndelete1_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Are you sure to delete data?", "Alert", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            if (dr == DialogResult.Yes)
            {
                long c_id = long.Parse(txtplayer.Text);
                d.del_player(c_id);
                obj.SaveChanges();
                MessageBox.Show("Deleted sucessfully ");
                loaddata1();
            }
            else
            {
                MessageBox.Show("You have cancelled deletion", "Abort", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

        }

        private void txtid_TextChanged(object sender, EventArgs e)
        {

        }

        private void bnadd1_Click(object sender, EventArgs e)
        {
            long p_id = long.Parse(txtplayer.Text);
            string p_name = txtplayername.Text;
            long country_id1 = long.Parse(txtcountryid.Text);
            string role = txtrole.Text;
            long rank = long.Parse(txticcrank.Text);
            long matchpld = long.Parse(txtmatch.Text);
            d.Addplayer(p_id, p_name, country_id1, role, rank, matchpld);
            obj.SaveChanges();
            MessageBox.Show("Added successfully");
            loaddata1();

        }

        private void bnupdate1_Click(object sender, EventArgs e)
        {
            long pid = long.Parse(txtplayer.Text);
            string pame = txtplayername.Text;
            long c_id1 = long.Parse(txtcountryid.Text);
            string r_ole = txtrole.Text;
            long rank = long.Parse(txticcrank.Text);
            long match_pld = long.Parse(txtmatch.Text);
            d.update_player(pid, pame, c_id1, r_ole, rank, match_pld);
            obj.SaveChanges();
            MessageBox.Show("Updated sucessfully ");
            loaddata1();

        }

        private void txtplayer_TextChanged(object sender, EventArgs e)
        {

        }

        private void datagrid1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void txtplayername_TextChanged(object sender, EventArgs e)
        {

        }

        private void homepage1_Load(object sender, EventArgs e)
        {
            loaddata1();
        }

        private void label5_Click_1(object sender, EventArgs e)
        {

        }

        private void btadd3_Click(object sender, EventArgs e)
        {
            long m_id = long.Parse(txtmatchno.Text);
            long c1_name = long.Parse(txtcountry1.Text);
            long c2_name = long.Parse(txtcountry2.Text);
            System.DateTime matchdate = System.DateTime.Parse(txtmatchdate.Text);
            string venue1 = txtvenue.Text;
            long result = long.Parse(txtresult.Text);

            d.addleague(m_id, c1_name, c2_name, matchdate, venue1, result);
            obj.SaveChanges();
            MessageBox.Show("Added successfully");
            loaddata2();
        }
        void loaddata2()
        {
            var st = from s in obj.League_Match_Details select s;
            datagrid3.DataSource = st.ToList();
        }

        private void btdelete3_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Are you sure to delete data?", "Alert", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            if (dr == DialogResult.Yes)
            {
                long m_id = long.Parse(txtmatchno.Text);
                d.deletematch(m_id);
                obj.SaveChanges();
                MessageBox.Show("Deleted sucessfully ");
                loadData();
            }
            else
            {
                MessageBox.Show("You have cancelled deletion", "Abort", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btupdate3_Click(object sender, EventArgs e)
        {
            long m_id = long.Parse(txtmatchno.Text);
            long c1_name = long.Parse(txtcountry1.Text);
            long c2_name = long.Parse(txtcountry2.Text);
            System.DateTime matchdate = System.DateTime.Parse(txtmatchdate.Text);
            string venue1 = txtvenue.Text;
            long result = long.Parse(txtresult.Text);

            d.update_league(m_id, c1_name, c2_name, matchdate, venue1, result);
            obj.SaveChanges();
            MessageBox.Show("Updated sucessfully ");
            loaddata1();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            long m_id = long.Parse(txtmatch_no.Text);
            long c1_name = long.Parse(txtcountryno1.Text);
            long c2_name = long.Parse(txtcountryno2.Text);
            System.DateTime matchdate = System.DateTime.Parse(txtmatch_date.Text);
            string venue1 = txtvenuee.Text;
            long result = long.Parse(txtresultt.Text);

            d.addsemi(m_id, c1_name, c2_name, matchdate, venue1, result);
            obj.SaveChanges();
            MessageBox.Show("Added successfully");
            loaddata4();
        }
        void loaddata4()
        {
            var st = from s in obj.Semifinal_Details select s;
            datagrid4.DataSource = st.ToList();
        }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btdelete_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Are you sure to delete data?", "Alert", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            if (dr == DialogResult.Yes)
            {
                long s_id = long.Parse(txtmatch_no.Text);
                d.deletesemi(s_id);
                obj.SaveChanges();
                MessageBox.Show("Deleted sucessfully ");
                loadData();
            }
            else
            {
                MessageBox.Show("You have cancelled deletion", "Abort", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btupdate_Click(object sender, EventArgs e)
        {
            long s_id = long.Parse(txtmatch_no.Text);
            long c1_name = long.Parse(txtcountryno1.Text);
            long c2_name = long.Parse(txtcountryno2.Text);
            System.DateTime matchdate = System.DateTime.Parse(txtmatch_date.Text);
            string venue1 = txtvenuee.Text;
            long result = long.Parse(txtresultt.Text);

            d.update_semi(s_id, c1_name, c2_name, matchdate, venue1, result);
            obj.SaveChanges();
            MessageBox.Show("Updated sucessfully ");
            loaddata4();
        }

        private void txtmatch_noo_TextChanged(object sender, EventArgs e)
        {

        }

        private void bttadd_Click(object sender, EventArgs e)
        {
            long m_id = long.Parse(txtmatch_noo.Text);
            long c1_name = long.Parse(txtcountryno11.Text);
            long c2_name = long.Parse(txtcountryno22.Text);
            System.DateTime matchdate = System.DateTime.Parse(txtmatch_datee.Text);
            string venue1 = txtvenuee1.Text;
            long result = long.Parse(txtresultt1.Text);

            d.addfinal(m_id, c1_name, c2_name, matchdate, venue1, result);
            obj.SaveChanges();
            MessageBox.Show("Added successfully");
            loaddata5();
        }
        void loaddata5()
        {
            var st = from s in obj.Final_Details select s;
            datagrid5.DataSource = st.ToList();
        }

        private void bttdelete_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Are you sure to delete data?", "Alert", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            if (dr == DialogResult.Yes)
            {
                long s_id = long.Parse(txtmatch_noo.Text);
                d.deletefinal(s_id);
                obj.SaveChanges();
                MessageBox.Show("Deleted sucessfully ");
                loadData();
            }
            else
            {
                MessageBox.Show("You have cancelled deletion", "Abort", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void bttupdate_Click(object sender, EventArgs e)
        {
            long s_id = long.Parse(txtmatch_noo.Text);
            long c1_name = long.Parse(txtcountryno11.Text);
            long c2_name = long.Parse(txtcountryno22.Text);
            System.DateTime matchdate = System.DateTime.Parse(txtmatch_datee.Text);
            string venue1 = txtvenuee1.Text;
            long result = long.Parse(txtresultt1.Text);

            d.update_final(s_id, c1_name, c2_name, matchdate, venue1, result);
            obj.SaveChanges();
            MessageBox.Show("Updated sucessfully ");
            loaddata5();
        }

        private void datagrid5_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
   }

