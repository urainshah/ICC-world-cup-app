﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace iccworldcup12
{
    public partial class Form1 : Form
    {
        public long id;
        public Form1()
        {
            InitializeComponent();
        }

        private void bnlogin_Click(object sender, EventArgs e)
        {

            dataaccesslayer dal = new dataaccesslayer();
            string un = txtlogin.Text;
            string pwd = txtpassword.Text;
            id = dal.CheckLogin(un, pwd);
            if (id > 0)
            {
                MessageBox.Show("Login Success");
                DialogResult = DialogResult.OK;
                homepage h = new homepage();
                h.Show();
            }
            else
            {
                MessageBox.Show("Login failed");
                DialogResult = DialogResult.Cancel;
            }
            
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
