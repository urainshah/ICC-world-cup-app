﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace iccworldcup12
{
    class dataaccesslayer
    {

        nttdbEntities1 ctx = new nttdbEntities1();
        public long CheckLogin(string un, string pwd)
        {
            long LID;

            //Select Loginid from UserLogin 
            //where Usernmae=lbus AND password=lbpw
            var res = (from obj in ctx.Admins
                       where obj.username == un && obj.password == pwd
                       select obj.id).FirstOrDefault();
            LID = res;
            return LID;
        }
        public void AddCountry(long cid, string cname, string ccaptain, long rank)
        {
            Country_Detail c = new Country_Detail();
            c.country_id = cid;
            c.country_name = cname;
            c.country_captain = ccaptain;
            c.rankings = rank;
            ctx.Country_Details.Add(c);
            ctx.SaveChanges();
        }
        public void deletecountry(long cid)
        {
            var del = (from obj in ctx.Country_Details
                       where obj.country_id == cid
                       select obj).FirstOrDefault();
            ctx.Country_Details.Remove(del);
            ctx.SaveChanges();

        }
        public void updatecountry(long cid1, long cid, string cname, string ccaptain, long rank)
        {
            var res = (from obj in ctx.Country_Details
                       where obj.country_id == cid1
                       select obj).FirstOrDefault();
            res.country_id = cid;
            res.country_name = cname;
            res.country_captain = ccaptain;
            res.rankings = rank;

            ctx.SaveChanges();
        }


        public void Addplayer(long p_id, string p_name, long c_id1, string role, long rank, long matchpld)
        {
            Player_Detail p = new Player_Detail();
            p.player_id = p_id;
            p.player_name = p_name;
            p.country_id = c_id1;
            p.role = role;
            p.icc_rankings = rank;
            p.nomatches_played = matchpld;
            ctx.Player_Details.Add(p);
            ctx.SaveChanges();
        }

        public void del_player(long p_id)
        {
            var del = (from obj in ctx.Player_Details
                       where obj.player_id == p_id
                       select obj).FirstOrDefault();
            ctx.Player_Details.Remove(del);
            ctx.SaveChanges();

        }
        public void update_player(long p_id, string p_name, long c_id1, string role, long rank, long matchpld)
        {
            var res = (from obj in ctx.Player_Details
                       where obj.player_id == p_id
                       select obj).FirstOrDefault();
            res.player_id = p_id;
            res.player_name = p_name; ;
            res.country_id = c_id1;
            res.role = role;
            res.icc_rankings = rank;
            res.nomatches_played = matchpld;

            ctx.SaveChanges();
        }

        public void addleague(long m_id, long c1_name, long c2_name, System.DateTime matchdate, string venue1, long result1)
        {
            League_Match_Detail q = new League_Match_Detail();
            q.match_no = m_id;
            q.country_id1 = c1_name;
            q.country_id2 = c2_name;
            q.match_date = matchdate;
            q.venue = venue1;
            q.result = result1;
            ctx.League_Match_Details.Add(q);
            ctx.SaveChanges();
        }

        public void deletematch(long mid)
        {
            var del = (from obj in ctx.League_Match_Details
                       where obj.match_no == mid
                       select obj).FirstOrDefault();
            ctx.League_Match_Details.Remove(del);
            ctx.SaveChanges();

        }

        public void update_league(long m_id, long c1_name, long c2_name, System.DateTime matchdate, string venue1, long result1)
        {
            var res = (from obj in ctx.League_Match_Details
                       where obj.match_no == m_id
                       select obj).FirstOrDefault();
            res.match_no = m_id;
            res.country_id1 = c1_name; ;
            res.country_id2 = c2_name;
            res.match_date = matchdate;
            res.venue = venue1;
            res.result = result1;

            ctx.SaveChanges();
        }
        public void addsemi(long s_id, long c1_name, long c2_name, System.DateTime matchdate, string venue1, long result1)
        {
            Semifinal_Detail w = new Semifinal_Detail();
            w.semifinal_no = s_id;
            w.country_id1 = c1_name;
            w.country_id2 = c2_name;
            w.match_date = matchdate;
            w.venue = venue1;
            w.result = result1;
            ctx.Semifinal_Details.Add(w);
            ctx.SaveChanges();
        }

        public void deletesemi(long s_id)
        {
            var del = (from obj in ctx.Semifinal_Details
                       where obj.semifinal_no == s_id
                       select obj).FirstOrDefault();
            ctx.Semifinal_Details.Remove(del);
            ctx.SaveChanges();

        }

        public void update_semi(long m_id, long c1_name, long c2_name, System.DateTime matchdate, string venue1, long result1)
        {
            var res = (from obj in ctx.Semifinal_Details
                       where obj.semifinal_no == m_id
                       select obj).FirstOrDefault();
            res.semifinal_no = m_id;
            res.country_id1 = c1_name; ;
            res.country_id2 = c2_name;
            res.match_date = matchdate;
            res.venue = venue1;
            res.result = result1;

            ctx.SaveChanges();
        }

        public void addfinal(long s_id, long c1_name, long c2_name, System.DateTime matchdate, string venue1, long result1)
        {
            Final_Detail w = new Final_Detail();
            w.finalmatch_no = s_id;
            w.country_id1 = c1_name;
            w.country_id2 = c2_name;
            w.match_date = matchdate;
            w.venue = venue1;
            w.result = result1;
            ctx.Final_Details.Add(w);
            ctx.SaveChanges();
        }

        public void deletefinal(long s_id)
        {
            var del = (from obj in ctx.Final_Details
                       where obj.finalmatch_no == s_id
                       select obj).FirstOrDefault();
            ctx.Final_Details.Remove(del);
            ctx.SaveChanges();

        }
        public void update_final(long m_id, long c1_name, long c2_name, System.DateTime matchdate, string venue1, long result1)
        {
            var res = (from obj in ctx.Final_Details
                       where obj.finalmatch_no == m_id
                       select obj).FirstOrDefault();
            res.finalmatch_no = m_id;
            res.country_id1 = c1_name; ;
            res.country_id2 = c2_name;
            res.match_date = matchdate;
            res.venue = venue1;
            res.result = result1;

            ctx.SaveChanges();
        }
    }
}